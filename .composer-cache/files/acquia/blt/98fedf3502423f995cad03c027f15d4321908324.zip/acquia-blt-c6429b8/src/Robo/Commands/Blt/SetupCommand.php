<?php

namespace Acquia\Blt\Robo\Commands\Blt;

use Acquia\Blt\Robo\BltTasks;

/**
 * Defines commands in the "setup:all" namespace.
 */
class SetupCommand extends BltTasks {

  /**
   * Executes source:build:* and installs Drupal via setup.strategy.
   *
   * @command setup
   */
  public function setup() {
    $this->say("Setting up local environment for site <comment>{$this->getConfigValue('site')}</comment>.");
    if ($this->getConfigValue('drush.alias')) {
      $this->say("Using drush alias <comment>@{$this->getConfigValue('drush.alias')}</comment>");
    }

    $commands = [
      'source:build',
      'drupal:deployment-identifier:init',
    ];

    switch ($this->getConfigValue('setup.strategy')) {
      case 'install':
        $commands[] = 'drupal:install';
        break;

      case 'sync':
        $commands[] = 'drupal:sync:default:site';
        break;

      case 'import':
        $commands[] = 'drupal:sql:import';
        $commands[] = 'drupal:update';
        break;
    }

    $this->invokeCommands($commands);
  }

}
