<?php

/**
 * @file
 * Pipelines environment specific settings.
 */

$databases['default']['default']['username'] = 'root';
$databases['default']['default']['password'] = 'root';
