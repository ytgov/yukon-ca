<?php

/**
 * @file
 * Code Studio settings.
 */

$databases['default']['default']['host'] = 'mysql';
