# How to get help

Please visit https://docs.acquia.com/blt/support/ for guidelines on how to get support for BLT.
