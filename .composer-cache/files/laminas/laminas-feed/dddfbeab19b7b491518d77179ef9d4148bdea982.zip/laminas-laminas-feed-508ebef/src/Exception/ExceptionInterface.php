<?php

declare(strict_types=1);

namespace Laminas\Feed\Exception;

use Throwable;

interface ExceptionInterface extends Throwable
{
}
