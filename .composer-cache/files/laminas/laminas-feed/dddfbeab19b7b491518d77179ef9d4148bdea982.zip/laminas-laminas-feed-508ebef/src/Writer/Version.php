<?php

declare(strict_types=1);

namespace Laminas\Feed\Writer;

// phpcs:ignore WebimpressCodingStandard.NamingConventions.AbstractClass.Prefix
abstract class Version
{
    public const VERSION = '2';
}
