---
edit_url: https://github.com/drush-ops/drush/blob/11.x/examples/example.site.yml
---
```yaml
--8<-- "examples/example.site.yml"
```
