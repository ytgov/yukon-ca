---
edit_url: https://github.com/drush-ops/drush/blob/11.x/examples/example.prompt.sh
---
```shell
--8<-- "examples/example.prompt.sh"
```
