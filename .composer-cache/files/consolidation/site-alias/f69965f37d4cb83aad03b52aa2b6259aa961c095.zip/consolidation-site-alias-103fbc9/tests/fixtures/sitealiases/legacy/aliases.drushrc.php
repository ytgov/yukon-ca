<?php

$aliases['production'] = [
    'uri' => 'example.com',
    'root' => '/path/to/drupal',
];

$aliases['staging'] = [
    'uri' => 'staging.example.com',
    'root' => '/path/to/drupal',
];
