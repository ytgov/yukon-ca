# Security Policy

**PLEASE DON'T DISCLOSE SECURITY-RELATED ISSUES PUBLICLY, [SEE BELOW](#reporting-a-vulnerability).**

## Reporting a Vulnerability

If you discover a security vulnerability within the Enlightn security-checker project, please send an email to Paras Malhotra at paras@laravel-enlightn.com. All security vulnerabilities will be promptly addressed.
