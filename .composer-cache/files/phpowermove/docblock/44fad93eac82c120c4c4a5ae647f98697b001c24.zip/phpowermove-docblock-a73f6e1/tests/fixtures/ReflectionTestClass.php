<?php declare(strict_types=1);

namespace phpowermove\docblock\tests\fixtures;

/**
 * Short Description.
 * 
 * @author gossi
 */
class ReflectionTestClass {
}
