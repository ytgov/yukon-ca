<?php declare(strict_types = 1);

namespace SlevomatCodingStandard\Sniffs\Files;

/**
 * @deprecated
 * @codeCoverageIgnore
 */
final class FunctionLengthSniff extends \SlevomatCodingStandard\Sniffs\Functions\FunctionLengthSniff
{

}
