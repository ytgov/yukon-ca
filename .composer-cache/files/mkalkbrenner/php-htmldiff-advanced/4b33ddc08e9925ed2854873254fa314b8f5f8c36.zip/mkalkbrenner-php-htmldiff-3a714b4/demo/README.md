Just write the code as shown in php file and enjoy.
