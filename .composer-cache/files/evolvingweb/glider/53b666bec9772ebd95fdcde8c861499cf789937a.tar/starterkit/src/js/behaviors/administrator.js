(function () {
  Drupal.behaviors.administrator = {
    attach () {
    },
    detach () {
    },
  };
}());
