# CONTENTS OF THIS FILE

 - Introduction
 - Installation
 - Creators
 - Requirements
 - configuration

## INTRODUCTION


Views Year Filter module add views filter by year exact,
instead of full date like mm-dd-yyyy you can use date year like yyyy.

## INSTALLATION

  - Install as you would normally install a contributed Drupal module. See:
    <https://www.drupal.org/docs/extending-drupal/installing-modules>
    for further information.


## REQUIREMENTS

  This module need no requirements.


## CONFIGURATION

 CREATORS

 Creator:
 - Berramou - <https://www.drupal.org/u/berramou>
