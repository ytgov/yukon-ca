06-MAY-2020
8.x-1.2 released. Drupal 9 compatible.

11-SEP-2018
8.x-1.1 released.

24-AUG-2017
8.x-1.0 released.

27-JUL-2017
8.x-1.0-beta1 released.

17-MAR-2017
8.x-1.0-alpha4 released.

12-MAR-2017
8.x-1.0-alpha3 released.

23-JUN-2016
8.x-1.0-alpha2 released.

07-MAY-2016
8.x-1.0-alpha1 released.
