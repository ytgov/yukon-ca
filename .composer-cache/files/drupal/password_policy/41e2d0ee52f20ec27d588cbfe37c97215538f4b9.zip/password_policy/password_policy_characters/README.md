password_policy_characters
===============

Password Policy Character Type Drupal Module

Implements a plugin for a Password Policy constraint to search for the count
 of specific character types (numeric, special, upper and lower).
