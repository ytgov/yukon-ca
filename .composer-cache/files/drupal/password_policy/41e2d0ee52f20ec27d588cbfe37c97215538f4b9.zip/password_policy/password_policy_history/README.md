password_policy_history
======================

This is a Drupal 8 module that adds a history plugin to the D8 Password
 Policy module. History is configured as a constraint within a password policy.
