password_policy_blacklist
=========================

Password Policy Blacklist Drupal module

Implements a plugin for a Password Policy constraint, allowing administrators to
restrict users from having blacklisted words or phrases in their passwords.
