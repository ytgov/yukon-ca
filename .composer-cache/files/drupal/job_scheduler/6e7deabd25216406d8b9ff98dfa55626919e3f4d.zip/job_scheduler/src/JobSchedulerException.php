<?php

namespace Drupal\job_scheduler;

/**
 * Use to make Job Scheduler exceptions identifiable by type.
 */
class JobSchedulerException extends \Exception {}
