### Workbench Email

### Installation

Download and enable the module as per usual

### Configuration

Create your email templates at admin/config/workflow/workbench-email-template.

Each template can define the body, subject and recipients.

Recipients can be one or more of the following

* All users with the selected role(s)
* The owner/author of the entity being moderated/transitioned
* The value of any email field-type

@todo update this screenshot

![Screenshot of template form](https://www.dropbox.com/s/1cjjs2u5ccuv6qh/Screenshot%202016-06-27%2014.29.24.png?dl=1)
