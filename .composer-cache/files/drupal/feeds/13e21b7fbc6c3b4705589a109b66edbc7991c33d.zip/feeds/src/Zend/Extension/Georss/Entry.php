<?php

namespace Drupal\feeds\Zend\Extension\Georss;

use Drupal\feeds\Laminas\Extension\Georss\Entry as LaminasEntry;

/**
 * Parses GeoRss data.
 *
 * @deprecated in favor of
 *   \Drupal\feeds\Laminas\Extension\Georss\Entry. Use that instead.
 */
class Entry extends LaminasEntry {
}
