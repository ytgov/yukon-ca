<?php

namespace Drupal\feeds\Exception;

/**
 * Exception thrown if the feed has not been updated since the last run.
 */
class NotModifiedException extends FeedsRuntimeException {}
