<?php

namespace Drupal\ui_patterns\Exception;

/**
 * Exception thrown in case of an invalid pattern rendering.
 *
 * @package Drupal\ui_patterns\Exception
 */
class PatternRenderException extends \Exception {

}
