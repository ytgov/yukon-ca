# UI Patterns Field Group

Integrates UI Patterns with the [Field Group](https://www.drupal.org/project/field_group) module.  
