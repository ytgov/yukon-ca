<?php

namespace Drupal\libraries\Annotation;

use Drupal\Component\Annotation\PluginID;

/**
 * Provides an annotation class for version detector plugins.
 *
 * @Annotation
 */
class VersionDetector extends PluginID {

}
