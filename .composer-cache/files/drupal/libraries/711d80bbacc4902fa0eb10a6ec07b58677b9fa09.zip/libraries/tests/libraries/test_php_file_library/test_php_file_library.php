<?php

/**
 * @file
 * Test PHP file.
 *
 * This file is part of the 'test_php_file_library' test library.
 *
 * @see \Drupal\Tests\libraries\Kernel\ExternalLibrary\PhpFile\PhpFileLibraryTest
 */

/**
 * A test function to be able to test whether this file was loaded or not.
 */
function _libraries_test_php_function() {
}
