# Tamper #

[![Build Status](https://travis-ci.org/ericgsmith/tamper.svg?branch=master)](https://travis-ci.org/ericgsmith/tamper)
[![Maintainability](https://api.codeclimate.com/v1/badges/494ae79569ca56e13d24/maintainability)](https://codeclimate.com/github/ericgsmith/tamper/maintainability)

Tamper module playground. 

[Follow the conversation on Drupal.org](https://www.drupal.org/node/2921727)
