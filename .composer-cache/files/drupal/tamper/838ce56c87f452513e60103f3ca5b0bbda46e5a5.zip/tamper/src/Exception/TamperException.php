<?php

namespace Drupal\tamper\Exception;

/**
 * Defines the tamper exception class.
 */
class TamperException extends \Exception {

}
