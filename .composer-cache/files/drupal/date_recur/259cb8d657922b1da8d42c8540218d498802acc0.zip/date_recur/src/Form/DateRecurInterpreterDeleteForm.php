<?php

declare(strict_types = 1);

namespace Drupal\date_recur\Form;

use Drupal\Core\Entity\EntityDeleteForm;

/**
 * Deletion form for interpreter entities.
 */
class DateRecurInterpreterDeleteForm extends EntityDeleteForm {}
