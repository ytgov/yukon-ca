<?php

/**
 * @file
 * Include all database dump files.
 */

include 'scheduler_data' . DIRECTORY_SEPARATOR . 'field_config.php';
include 'scheduler_data' . DIRECTORY_SEPARATOR . 'field_config_instance.php';
include 'scheduler_data' . DIRECTORY_SEPARATOR . 'node.php';
include 'scheduler_data' . DIRECTORY_SEPARATOR . 'node_revision.php';
include 'scheduler_data' . DIRECTORY_SEPARATOR . 'node_type.php';
include 'scheduler_data' . DIRECTORY_SEPARATOR . 'role.php';
include 'scheduler_data' . DIRECTORY_SEPARATOR . 'role_permission.php';
include 'scheduler_data' . DIRECTORY_SEPARATOR . 'scheduler.php';
include 'scheduler_data' . DIRECTORY_SEPARATOR . 'system.php';
include 'scheduler_data' . DIRECTORY_SEPARATOR . 'users.php';
include 'scheduler_data' . DIRECTORY_SEPARATOR . 'variable.php';
