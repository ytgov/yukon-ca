<?php

namespace Drupal\xmlsitemap;

/**
 * Base XmlSitemapException class.
 */
class XmlSitemapException extends \Exception {}
