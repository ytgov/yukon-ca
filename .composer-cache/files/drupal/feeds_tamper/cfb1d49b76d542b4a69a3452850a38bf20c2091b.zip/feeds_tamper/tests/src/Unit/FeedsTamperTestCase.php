<?php

namespace Drupal\Tests\feeds_tamper\Unit;

use Drupal\Tests\feeds\Unit\FeedsUnitTestCase;

/**
 * Base class for feeds tamper unit tests.
 */
abstract class FeedsTamperTestCase extends FeedsUnitTestCase {}
