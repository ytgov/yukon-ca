<?php declare(strict_types=1);

namespace DrupalCodeGenerator\Exception;

/**
 * The exception interface for DCG commands.
 */
interface ExceptionInterface extends \Throwable {

}
