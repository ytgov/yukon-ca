<?php

return array(
	'yearly' => array(
		'1' => 'chaque année',
		'2' => 'une années sur deux',
		'else' => 'toutes les %{interval} années'
	)
);